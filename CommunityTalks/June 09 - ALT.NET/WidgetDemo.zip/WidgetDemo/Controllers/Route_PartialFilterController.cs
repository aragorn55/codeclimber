﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using WidgetDemo.Actions;
using WidgetDemo.Models;

namespace WidgetDemo.Controllers
{
    public class Route_PartialFilterController : Controller
    {
        private IRouteRepository _repository;
        public Route_PartialFilterController()
        {
            _repository=new RouteRepository();
        }

        [RouteListFilter]
        public ActionResult Index()
        {
            ViewData["Message"] =
                "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec elementum dolor at mauris consequat tempus. Pellentesque at pellentesque enim. Vestibulum sodales sollicitudin lacus, eget aliquet metus luctus nec. Fusce eu congue ante. Fusce a nibh ante. Sed a dui nec lacus tempus egestas quis ac felis. Sed eget felis purus, ac tincidunt enim. Suspendisse venenatis suscipit diam, ut scelerisque dolor cursus at. Donec vitae massa sed nibh porttitor tincidunt sit amet quis libero. Maecenas venenatis, nibh sed rutrum tempor, erat sapien convallis neque, in tincidunt metus augue nec nulla. Nulla tempor neque et ligula molestie ut feugiat nisi iaculis. Praesent iaculis orci eget urna fermentum posuere. Donec eu urna sit amet turpis scelerisque iaculis. Curabitur sed mi massa. Sed suscipit accumsan venenatis. Nulla facilisi. Ut ultricies mauris libero.";
            return View();
        }

        [RouteListFilter]
        public ActionResult Details(string name)
        {
            var route = _repository.GetRoute(name);
            if (route != null)
                return View(route);
            return RedirectToAction("RouteNotFound");
        }

        public ActionResult RouteNotFound()
        {
            return View();
        }
    }
}