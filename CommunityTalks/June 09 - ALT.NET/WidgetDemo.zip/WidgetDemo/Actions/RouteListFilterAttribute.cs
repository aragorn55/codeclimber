﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WidgetDemo.Models;

namespace WidgetDemo.Actions
{
    public class RouteListFilterAttribute: ActionFilterAttribute
    {
        private IRouteRepository _routeRepository;

        public RouteListFilterAttribute()
        {
            _routeRepository = new RouteRepository();
        }

        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            if(!filterContext.Canceled)
            {
                ViewResult result = filterContext.Result as ViewResult;
                if (result != null)
                {
                    result.ViewData["RouteList"] = _routeRepository.GetTopRoutes();
                }
            }
        }
    }
}
