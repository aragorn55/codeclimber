﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WidgetDemo.Models
{
    public class Route
    {
        public string Name { get; set; }
        public DifficutlyLevel Difficutly { get; set; }
        public double Length { get; set; }
        public double Gain { get; set; }
        public double AverageGrade { get; set; }
    }

    public enum DifficutlyLevel
    {
        Easy,
        Medium,
        Hard,
        Strenuous,
        ArmstrongLevel
    }
}