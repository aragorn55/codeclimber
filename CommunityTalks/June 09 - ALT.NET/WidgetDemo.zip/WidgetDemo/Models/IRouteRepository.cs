namespace WidgetDemo.Models
{
    public interface IRouteRepository
    {
        RouteList GetTopRoutes();
        Route GetRoute(string name);
    }
}