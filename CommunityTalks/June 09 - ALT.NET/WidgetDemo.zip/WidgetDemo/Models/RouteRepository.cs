﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WidgetDemo.Models
{
    public class RouteRepository: IRouteRepository
    {
        private RouteList _routes;
        public RouteRepository()
        {
            _routes = new RouteList();

            _routes.Add(new Route()
                            {
                                Name = "Passo dello Stelvio",
                                Length = 24.3,
                                AverageGrade = 7.4,
                                Gain = 1808,
                                Difficutly = DifficutlyLevel.Hard
                            }
                );

            _routes.Add(new Route()
                            {
                                Name = "Mont Ventoux",
                                Length = 21.2,
                                AverageGrade = 7.2,
                                Gain = 1532,
                                Difficutly = DifficutlyLevel.Medium
                            }
                );

            _routes.Add(new Route()
                            {
                                Name = "Mortirolo",
                                Length = 12.4,
                                AverageGrade = 10.5,
                                Gain = 1300,
                                Difficutly = DifficutlyLevel.Strenuous
                            }
                );

            _routes.Add(new Route()
                            {
                                Name = "Mount Washington",
                                Length = 12.4,
                                AverageGrade = 11.5,
                                Gain = 1420,
                                Difficutly = DifficutlyLevel.ArmstrongLevel
                            }
                );

            _routes.Add(new Route()
                            {
                                Name = "Brinzio",
                                Length = 8.28,
                                AverageGrade = 3.5,
                                Gain = 292,
                                Difficutly = DifficutlyLevel.Easy
                            }
                );
        }

        public RouteList GetTopRoutes()
        {
            var query = from r in _routes
                        orderby r.Name
                        select r;
            return new RouteList(query);
        }

        public Route GetRoute(string name)
        {
            var route = from r in _routes
                        where r.Name == name
                        select r;
            return route.First();
        }
    }
}