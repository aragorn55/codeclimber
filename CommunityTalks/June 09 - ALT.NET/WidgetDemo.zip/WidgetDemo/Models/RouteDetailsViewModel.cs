﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WidgetDemo.Models
{
    public class RouteDetailsViewModel: BaseRouteViewModel
    {
        public Route Route { get; set; }
    }
}
