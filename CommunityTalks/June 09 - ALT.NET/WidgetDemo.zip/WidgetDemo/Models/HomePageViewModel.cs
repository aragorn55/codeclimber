﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WidgetDemo.Models
{
    public class HomePageViewModel: BaseRouteViewModel
    {
        public string Message { get; set; }
    }
}
