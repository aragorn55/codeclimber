namespace MvcBestPractices.Models
{
    public class ShowPostModel
    {
        public Post Post { get; set; }
    }
}