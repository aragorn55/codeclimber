namespace MvcBestPractices.Models
{
    public class EditPostModel
    {
        public Post Post { get; set; }
    }
}