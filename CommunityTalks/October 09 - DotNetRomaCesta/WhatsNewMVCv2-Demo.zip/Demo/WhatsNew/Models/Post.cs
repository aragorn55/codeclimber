﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace WhatsNew.Models
{
    public class Post
    {
        public override string ToString()
        {
            return string.Concat(Title, " ", Content);
        }

        //[HiddenInput(DisplayValue = false)] 
        [Range(0, 100),Required]
        public int Id { get; set; }

        public string Content { get; set; }

        [StringLength(15, ErrorMessage = "{0} is too long for a title"), Required]
        public string Title { get; set; }

        [UIHint("Category"), DisplayName("Post Category")]
        public String Category { get; set; }
    }
}