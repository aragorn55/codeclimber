﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WhatsNew.Models;

namespace WhatsNew.Controllers
{
    [HandleError]
    public class HomeController : Controller
    {
        private InMemoryPostModel _model;

        public HomeController()
        {
            _model = new InMemoryPostModel();
        }

        public ActionResult Index()
        {
            ViewData["Message"] = "Welcome to ASP.NET MVC!";

            var post = _model.GetPost(1);
            return View(post);
        }

        public ActionResult About()
        {
            return View();
        }
    }
}
