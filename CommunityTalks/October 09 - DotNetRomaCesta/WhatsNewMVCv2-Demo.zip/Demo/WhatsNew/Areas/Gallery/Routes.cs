﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WhatsNew.Areas.Gallery
{
    public class Routes : AreaRegistration
    {
        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "gallery-Default",                                              // Route name
                "gallery/{controller}/{action}/{id}",                      // URL with parameters
                new { controller = "Gallery", action = "Index", id = "" }  // Parameter defaults
            );
        }

        public override string AreaName
        {
            get { return "gallery"; }
        }
    }
}
