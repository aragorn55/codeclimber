using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using WhatsNew.Models;

namespace WhatsNew.Areas.Blog.Controllers
{
    public class BlogController : Controller
    {
        private InMemoryPostModel _model;

        public BlogController()
        {
            _model = new InMemoryPostModel();
        }

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Show(int postId)
        {
            var post = _model.GetPost(postId);
            return View(post);
        }

        public ActionResult Edit(int postId)
        {
            var post = _model.GetPost(postId);
            return View(post);
        }

        public ActionResult EditAll(int postId)
        {
            var post = _model.GetPost(postId);
            return View(post);
        }

        [HttpPost]
        public ActionResult Edit(Post post)
        {
            return View(post);
        }
    }
}
