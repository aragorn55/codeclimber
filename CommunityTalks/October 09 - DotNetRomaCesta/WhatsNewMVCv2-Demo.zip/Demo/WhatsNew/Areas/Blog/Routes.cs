﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WhatsNew.Areas.Blog
{
    public class Routes: AreaRegistration
    {
        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "blog-Default",                                              // Route name
                "blog/{controller}/{action}/{id}",                      // URL with parameters
                new { controller = "Blog", action = "Index", id = "" }  // Parameter defaults
            );
        }

        public override string AreaName
        {
            get { return "blog"; }
        }
    }
}
