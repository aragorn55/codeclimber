using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using JoinTheConf.Models;


namespace JoinTheConf.Areas.Public.Controllers
{   
    public class ConferencesController : Controller
    {
        private JoinTheConfContext context = new JoinTheConfContext();

        //
        // GET: /Conference/

        public ViewResult Index()
        {
            return View(context.Conferences.ToList());
        }

    }
}