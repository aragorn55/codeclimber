using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using JoinTheConf.Models;


namespace JoinTheConf.Areas.Public.Controllers
{   
    public class AttendeesController : Controller
    {
        private JoinTheConfContext context = new JoinTheConfContext();

        public ActionResult Attendees(int id)
        {
            Conference conference = context.Conferences.Single(c => c.Id == id);
            return PartialView("_attendees", conference.Attendees);
        }

        //
        // GET: /Attendee/Create

        public ActionResult Create()
        {
			ViewBag.PossibleConferences = context.Conferences;
            return View();
        } 

        //
        // POST: /Attendee/Create

        [HttpPost]
        public ActionResult Create(Attendee attendee, int id)
        {
            attendee.ConferenceId = id;
            if (ModelState.IsValid)
            {
				context.Attendees.Add(attendee);
				context.SaveChanges();
				return RedirectToAction("Index","Conferences");  
            }

			ViewBag.PossibleConferences = context.Conferences;
            return View(attendee);
        }

        public JsonResult CheckEmail(string email)
        {
            var result = context.Attendees.SingleOrDefault(a => a.Email.Equals(email));
            return Json(result == null, JsonRequestBehavior.AllowGet);
        }


    }
}