using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using JoinTheConf.Models;

namespace JoinTheConf.Controllers
{   
    public class AttendeesController : Controller
    {
        private JoinTheConfContext context = new JoinTheConfContext();

        //
        // GET: /Attendee/

        public ViewResult Index()
        {
            return View(context.Attendees.Include(attendee => attendee.Conference).ToList());
        }

        //
        // GET: /Attendee/Details/5

        public ViewResult Details(int id)
        {
			Attendee attendee = context.Attendees.Single(x => x.Id == id);
            return View(attendee);
        }

        //
        // GET: /Attendee/Create

        public ActionResult Create()
        {
			ViewBag.PossibleConferences = context.Conferences;
            return View();
        } 

        //
        // POST: /Attendee/Create

        [HttpPost]
        public ActionResult Create(Attendee attendee)
        {
            if (ModelState.IsValid)
            {
				context.Attendees.Add(attendee);
				context.SaveChanges();
				return RedirectToAction("Index");  
            }

			ViewBag.PossibleConferences = context.Conferences;
            return View(attendee);
        }
        
        //
        // GET: /Attendee/Edit/5
 
        public ActionResult Edit(int id)
        {
			Attendee attendee = context.Attendees.Single(x => x.Id == id);
			ViewBag.PossibleConferences = context.Conferences;
			return View(attendee);
        }

        //
        // POST: /Attendee/Edit/5

        [HttpPost]
        public ActionResult Edit(Attendee attendee)
        {
            if (ModelState.IsValid)
            {
				context.Entry(attendee).State = EntityState.Modified;
                context.SaveChanges();
                return RedirectToAction("Index");
            }
			ViewBag.PossibleConferences = context.Conferences;
            return View(attendee);
        }

        //
        // GET: /Attendee/Delete/5
 
        public ActionResult Delete(int id)
        {
			Attendee attendee = context.Attendees.Single(x => x.Id == id);
            return View(attendee);
        }

        //
        // POST: /Attendee/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            Attendee attendee = context.Attendees.Single(x => x.Id == id);
            context.Attendees.Remove(attendee);
			context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}