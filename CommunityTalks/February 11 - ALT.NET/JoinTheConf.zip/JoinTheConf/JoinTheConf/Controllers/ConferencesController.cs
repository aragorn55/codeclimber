using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using JoinTheConf.Models;

namespace JoinTheConf.Controllers
{   
    public class ConferencesController : Controller
    {
        private JoinTheConfContext context = new JoinTheConfContext();

        //
        // GET: /Conference/

        public ViewResult Index()
        {
            return View(context.Conferences.Include(conference => conference.Attendees).ToList());
        }

        //
        // GET: /Conference/Details/5

        public ViewResult Details(int id)
        {
			Conference conference = context.Conferences.Single(x => x.Id == id);
            return View(conference);
        }

        //
        // GET: /Conference/Create

        public ActionResult Create()
        {
            return View();
        } 

        //
        // POST: /Conference/Create

        [HttpPost]
        public ActionResult Create(Conference conference)
        {
            if (ModelState.IsValid)
            {
				context.Conferences.Add(conference);
				context.SaveChanges();
				return RedirectToAction("Index");  
            }

            return View(conference);
        }
        
        //
        // GET: /Conference/Edit/5
 
        public ActionResult Edit(int id)
        {
			Conference conference = context.Conferences.Single(x => x.Id == id);
			return View(conference);
        }

        //
        // POST: /Conference/Edit/5

        [HttpPost]
        public ActionResult Edit(Conference conference)
        {
            if (ModelState.IsValid)
            {
				context.Entry(conference).State = EntityState.Modified;
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(conference);
        }

        //
        // GET: /Conference/Delete/5
 
        public ActionResult Delete(int id)
        {
			Conference conference = context.Conferences.Single(x => x.Id == id);
            return View(conference);
        }

        //
        // POST: /Conference/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            Conference conference = context.Conferences.Single(x => x.Id == id);
            context.Conferences.Remove(conference);
			context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}