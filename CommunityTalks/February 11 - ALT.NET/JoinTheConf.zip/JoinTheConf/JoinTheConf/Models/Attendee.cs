﻿using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace JoinTheConf.Models
{
    public class Attendee
    {
        public int Id { get; set; }
        public int ConferenceId { get; set; }
        [Required]
        public string Name { get; set; }
        [Required, Remote("CheckEmail", "Attendees", "Public", ErrorMessage = "Email already registered")]
        public string Email { get; set; }

        virtual public Conference Conference { get; set; }
    }
}