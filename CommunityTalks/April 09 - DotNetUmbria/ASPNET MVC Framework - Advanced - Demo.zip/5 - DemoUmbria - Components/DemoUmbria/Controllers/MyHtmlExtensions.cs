﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DemoUmbria.Models;

namespace DemoUmbria.Controllers
{
    static public class MyHtmlExtensions
    {
        public static string RenderMyDropDown(this HtmlHelper helper, IList<Post> list)
        {
            string html = "<form method=\"GET\" action=\"Page\"><select name=\"PostID\">";
            foreach (var post in list)
            {
                html += String.Format("<option value=\"" + post.Id + "\">" + post.Title + "</option>");
            }
            html += "</select><input type=\"submit\" value=\"->\"></form>";
            return html;
        }
    }
}
