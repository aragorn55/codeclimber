using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using DemoUmbria.Models;

namespace DemoUmbria.Controllers
{
    public class PostController : Controller
    {
        private readonly IPostModel _model;

        public PostController()
            : this(new InMemoryPostModel())
        {
        }

        public PostController(IPostModel model)
        {
            _model = model;
        }

        public ActionResult Index()
        {
            return List();
        }

        public ActionResult List()
        {
            ViewData["Title"] = "Post List";
            ViewData["posts"] = _model.GetPosts(10);
            return View("List");
        }

        public ActionResult JsonList()
        {
            var posts = _model.GetPosts(30);
            GridModel model = new GridModel();
            model.total = 3;
            model.page = 1;
            model.records = 30;
            model.rows = posts;

            return Json(model);
        }

        public ActionResult Page(int PostID)
        {
            if (PostID > 10)
            {
                TempData["ID"] = PostID;
                return RedirectToAction("Error");
            }

            Post post = _model.GetPost((int)PostID);
            if (post == null)
            {
                TempData["ID"] = PostID;
                return RedirectToAction("Error");
            }
            return View(post);
        }

    }

    internal class GridCell
    {
    }

    internal class GridModel
    {
        public int total;
        public int page;
        public int records;
        public IList<Post> rows;
    }
}
