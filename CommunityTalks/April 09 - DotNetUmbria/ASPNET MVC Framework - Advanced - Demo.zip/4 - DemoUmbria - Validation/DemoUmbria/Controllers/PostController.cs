using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using DemoUmbria.Models;

namespace DemoUmbria.Controllers
{
    public class PostController : Controller
    {
        private readonly IPostModel _model;

        public PostController()
            : this(new InMemoryPostModel())
        {
        }

        public PostController(IPostModel model)
        {
            _model = model;
        }

        public ActionResult Index()
        {
            return List();
        }

        public ActionResult List()
        {
            ViewData["Title"] = "Post List";
            ViewData["posts"] = _model.GetPosts(10);
            return View("List");
        }

        public ActionResult Edit(int PostID)
        {
            Post post = _model.GetPost((int)PostID);
            return View(post);
        }

        [AcceptVerbs(HttpVerbs.Post)]
        // 2 - Escludere propriet�
        public ActionResult Edit([Bind(Exclude = "id")]  Post post)
        //public ActionResult Edit(Post post)
        {
            // 1 - Scommentare per mostare errori custom aggiuntivi al modelbinder
            if(String.IsNullOrEmpty(post.Title))
                ModelState.AddModelError("Title","Title is required");
            return View(post);
        }

        public ActionResult Page(int PostID)
        {
            if (PostID > 10)
            {
                TempData["ID"] = PostID;
                return RedirectToAction("Error");
            }

            Post post = _model.GetPost((int)PostID);
            if (post == null)
            {
                TempData["ID"] = PostID;
                return RedirectToAction("Error");
            }
            return View(post);
        }

    }
}
