﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using DomainModel;
using xVal.ServerSide;

namespace BookingsDemo.Controllers
{
    public class HomeController : Controller
    {
        [AcceptVerbs(HttpVerbs.Get)]
        public ViewResult CreateBooking()
        {
            return View();
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult CreateBooking(Booking booking)
        {
            try {
                BookingManager.PlaceBooking(booking);                
            }
            catch(RulesException ex) {
                ex.AddModelStateErrors(ModelState, "booking");
            }

            return ModelState.IsValid ? RedirectToAction("Completed")
                                      : (ActionResult) View();
        }

        public ViewResult Completed()
        {
            return View(); // Displays "Thanks for booking"
        }

        public ActionResult Index()
        {
            return RedirectToAction("CreateBooking");
        }
    }
}
