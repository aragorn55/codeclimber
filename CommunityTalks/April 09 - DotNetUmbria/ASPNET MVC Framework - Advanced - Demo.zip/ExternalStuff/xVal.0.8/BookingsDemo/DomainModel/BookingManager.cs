using System;
using System.Linq;
using xVal.ServerSide;

namespace DomainModel
{
    public static class BookingManager
    {
        public static void PlaceBooking(Booking booking)
        {
            var errors = DataAnnotationsValidationRunner.GetErrors(booking);
            if (errors.Any())
                throw new RulesException(errors);

            // Business rule: Can't place bookings on Sundays
            if(booking.ArrivalDate.DayOfWeek == DayOfWeek.Sunday)
                throw new RulesException("ArrivalDate", 
                                         "Bookings are not permitted on Sundays",
                                         booking);

            // Todo: save to database or whatever
        }
    }
}