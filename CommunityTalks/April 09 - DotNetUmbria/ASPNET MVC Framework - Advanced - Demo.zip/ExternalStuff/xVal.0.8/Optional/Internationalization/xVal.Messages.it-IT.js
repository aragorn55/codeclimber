﻿/* If you want default messages in English, you don't need to reference this file, because the messages are 
 * in English by default anyway. This file exists only for reference during translation.
 *
 * To get default messages in any other language (or a different dialect of English):
 *  (1) Make a copy of this file and call it anything else, for example: xVal.Messages.fr-FR.js
 *  (2) Edit your copy to specify messages in your chosen language
 *  (3) Reference your file in your project using a <script> tag.
 * Simply referencing your custom file will override the default messages with your messages.
 *
 * Note that at present this only works when using jQuery Validation (not ASP.NET native) but
 * I will add localisation support in ASP.NET native validation shortly.
*/
var xVal = xVal || {};
xVal.Messages = {
    "Required" : "Questo valore è obbligatorio.",
    "DataType_EmailAddress" : "Non è un indirizzo di email valido",
    "DataType_Integer" : "Non è un numero intero valido.",
    "DataType_Decimal" : "Non è un numero valido.",
    "DataType_Date" : "Non è una data valida.",
    "DataType_DateTime" : "Non è valore data e ora valido",
    "DataType_Currency" : "Non è un importo valido.",
    "DataType_CreditCardLuhn" : "Non è un numero di carta di credito valido",
    "Regex" : "Questo valore non è valido.",
    "Range_Numeric_Min" : "Il valore non dev'essere minore di {0}.",
    "Range_Numeric_Max" : "Il valore non dev'essere maggiore di {0}.",
    "Range_Numeric_MinMax" : "Il valore dev'essere compreso tra {0} e {1}.",
    "Range_String_Min" : "Il valore non dev'essere alfabeticamente precedente a '{0}'.",
    "Range_String_Max" : "Il valore non dev'essere alfabeticamente successivo a '{0}'.",
    "Range_String_MinMax" : "Il valore dev'essere alfabeticamente compreso tra '{0}' e '{1}'.",
    "Range_DateTime_Min" : "Date anteriori a {0} non sono valide.",
    "Range_DateTime_Max": "Date posteriori a {0} non sono valide.",
    "Range_DateTime_MinMax": "La data dev'essere compresa tra {0} e {1}.",
    "StringLength_Min": "Il valore non dev'essere più corto di {0} caratteri.",
    "StringLength_Max": "Il valore non dev'essere più lungo di {0} caratteri.",
    "StringLength_MinMax": "Il valore dev'essere lungo tra {0} e {1} caratteri.",
    "Comparison_Equals" : "Questo valore dev'essere uguale a {0}.",
    "Comparison_DoesNotEqual" : "Questo valore dev'essere diverso da {0}."
};