jQuery("#ttogrid").click(function (){
	tableToGrid("#mytable");
});