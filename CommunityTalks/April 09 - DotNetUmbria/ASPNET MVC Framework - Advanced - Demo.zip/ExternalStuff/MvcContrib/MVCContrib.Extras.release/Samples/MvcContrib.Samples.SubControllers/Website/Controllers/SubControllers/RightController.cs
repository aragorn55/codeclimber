using MvcContrib;

namespace Website.Controllers.SubControllers
{
	public class RightController : SubController
	{
		public string Right(string stringToDisplay)
		{
			return stringToDisplay;
		}
	}
}