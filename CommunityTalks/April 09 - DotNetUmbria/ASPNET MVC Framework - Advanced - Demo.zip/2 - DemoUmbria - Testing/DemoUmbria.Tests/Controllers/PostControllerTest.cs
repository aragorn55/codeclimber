﻿using System.Collections.Generic;
using System.Web.Mvc;
using DemoUmbria.Controllers;
using DemoUmbria.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Rhino.Mocks;

namespace DemoUmbria.Tests.Controllers
{
    [TestClass]
    public class PostControllerTest
    {
        [TestMethod]
        public void Page_Redirects_ToError_with_non_existent_id()
        {
            MockRepository repository = new MockRepository();

            IPostModel postModel;
            using (repository.Record())
            {
                postModel = repository.StrictMock<IPostModel>();

                Expect.Call(postModel.GetPost(0))
                    .IgnoreArguments().Return(null);
            }
            PostController controller = new PostController(postModel);

            using (repository.Playback())
            {
                controller.TempData = new TempDataDictionary();
                ActionResult result = controller.Page(8);

                RedirectToRouteResult redirectResult = result as RedirectToRouteResult;
                Assert.IsNotNull(redirectResult);
                Assert.AreEqual(8, (int)controller.TempData["ID"]);
            }
        }

        [TestMethod]
        public void Page_Redirects_ToError_with_id_gt_10()
        {

            PostController controller = new PostController();

            controller.TempData = new TempDataDictionary();
            ActionResult result = controller.Page(100);

            RedirectToRouteResult redirectResult = result as RedirectToRouteResult;
            Assert.IsNotNull(redirectResult);
            Assert.AreEqual(100, (int)controller.TempData["ID"]);

        }

        [TestMethod]
        public void List_Return_Last10Posts()
        {
            MockRepository repository = new MockRepository();
            IPostModel postModel = repository.StrictMock<IPostModel>();
            using (repository.Record())
            {
                IList<Post> postlist = new List<Post>();
                for (int i = 0; i < 10; i++)
                    postlist.Add(new Post());

                Expect.Call(postModel.GetPosts(10)).Return(postlist);
            }
            using (repository.Playback())
            {
                PostController controller = new PostController(postModel);
                ActionResult result = controller.List();
                ViewResult viewResult = result as ViewResult;
                Assert.IsNotNull(viewResult);
                IList<Post> list = viewResult.ViewData["posts"] as IList<Post>;
                Assert.AreEqual(10, list.Count);
                Assert.AreEqual("List", viewResult.ViewName);
            }
        }

        [TestMethod]
        public void Page_Return_Post()
        {
            MockRepository repository = new MockRepository();
            IPostModel postModel = repository.StrictMock<IPostModel>();
            using (repository.Record())
            {
                Post post = new Post
                {
                    Title = string.Format("Post Number 5"),
                    Content = string.Format("This is the content of post 5"),
                    Id = 5
                };

                Expect.Call(postModel.GetPost(5)).Return(post);
            }

            using (repository.Playback())
            {
                PostController controller = new PostController(postModel);
                ActionResult result = controller.Page(5);

                ViewResult viewResult = result as ViewResult;
                Assert.IsNotNull(viewResult);

                Post post = viewResult.ViewData.Model as Post;
                Assert.AreEqual(5, post.Id);
            }
        }

    }
}
