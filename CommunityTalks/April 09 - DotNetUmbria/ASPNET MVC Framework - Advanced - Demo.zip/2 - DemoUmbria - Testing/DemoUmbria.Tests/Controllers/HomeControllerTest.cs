﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DemoUmbria;
using DemoUmbria.Controllers;
using Rhino.Mocks;

namespace DemoUmbria.Tests.Controllers
{
    [TestClass]
    public class HomeControllerTest
    {
        [TestMethod]
        public void Index()
        {
            // Arrange
            HomeController controller = new HomeController();

            // Act
            ViewResult result = controller.Index() as ViewResult;

            // Assert
            ViewDataDictionary viewData = result.ViewData;
            Assert.AreEqual("Welcome to ASP.NET MVC!", viewData["Message"]);
        }

        [TestMethod]
        public void About_Shows_UserAgent()
        {
            // Arrange
            HomeController controller = new HomeController();

            var controllerContext = MockRepository.GenerateMock<ControllerContext>();
            var httpContextBase = MockRepository.GenerateMock<HttpContextBase>();
            var httpRequest = MockRepository.GenerateMock<HttpRequestBase>();
            httpRequest.Stub(r => r.UserAgent).Return("MyFake UserAgent");
            httpContextBase.Stub(c => c.Request).Return(httpRequest);
            controllerContext.Stub(c => c.HttpContext).Return(httpContextBase);


            controller.ControllerContext = controllerContext;

            // Act
            ViewResult result = controller.About() as ViewResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual("MyFake UserAgent",result.ViewData["UserAgent"]);
            httpRequest.AssertWasCalled(x => { var dummy = x.UserAgent; });
        }
    }
}
