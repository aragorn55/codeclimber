﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace DemoUmbria.Models
{
    public class Post
    {
        public override string ToString()
        {
            return string.Concat(title, " ", content);
        }

        [Required( ErrorMessage = "ID Post è obbligatorio")]
        [Range(0,20, ErrorMessage = "Id Post non valido")]
        public int Id { get; set; }

        private string title;
        private string content;

        [StringLength(50, ErrorMessage = "Contenuto troppo lungo (max 50)")]
        public string Content
        {
            get { return content; }
            set { content = value; }
        }

        [Required(ErrorMessage = "Un post deve avere un titolo")]
        public string Title
        {
            get { return title; }
            set { title = value; }
        }
    }
}
