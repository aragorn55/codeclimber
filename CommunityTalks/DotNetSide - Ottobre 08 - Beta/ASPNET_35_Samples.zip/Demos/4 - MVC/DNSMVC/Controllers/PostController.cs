using System.Web.Mvc;
using DNSMVC.Models;

namespace DNSMVC.Controllers
{
    public class PostController : Controller
    {
        private readonly IPostModel _model;

        public PostController() : this(new InMemoryPostModel())
        {
        }

        public PostController(IPostModel model)
        {
            _model = model;
        }

        public ActionResult Index()
        {
            return List();
        }

        public ActionResult List()
        {
            ViewData["Title"] = "Post List";
            ViewData["posts"] = _model.GetPosts(10);
            return View("List");
        }

        public ActionResult Error()
        {
            ViewData["ErrorMessage"] = string.Format("Hai richesto un id troppo alto: {0}", TempData["ID"]);
            return View();
        }



        public ActionResult Page(int PostID)
        {
            if (PostID > 10)
            {
                TempData["ID"] = PostID;
                return RedirectToAction("Error");
            }

            Post post = _model.GetPost((int)PostID);
            if (post == null)
            {
                TempData["ID"] = PostID;
                return RedirectToAction("Error");
            }
            return View(post);
        }
    }
}