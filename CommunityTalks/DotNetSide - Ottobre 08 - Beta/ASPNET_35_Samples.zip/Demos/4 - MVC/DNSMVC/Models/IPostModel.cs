using System.Collections.Generic;
using DNSMVC.Models;

namespace DNSMVC.Models
{
    public interface IPostModel
    {
        IList<Post> GetPosts(int i);
        Post GetPost(int id);
    }
}