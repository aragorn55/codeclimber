﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Compilation;
using System.Web.Mvc;
using System.Web.Routing;

namespace RouteDebugger
{
    public class MvcApplication : System.Web.HttpApplication
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");


            //Route from sample 1

            Route simpleBlogArchiveRoute = new Route(
                "archive/{year}/{month}/{day}",
                new EventsRouteHandler()
                );

            simpleBlogArchiveRoute.Defaults = new RouteValueDictionary(
                                            new
                                            {
                                                year = 2008,
                                                month = 0,
                                                day = 0,
                                                controller = "Home",
                                                action = "Index"
                                            });

            simpleBlogArchiveRoute.Constraints = new RouteValueDictionary(
                                            new
                                            {
                                                year = @"\d{2}|\d{4}",
                                                month = @"\d{1,2}",
                                                day = new DateIsValidConstraint()
                                            });

            routes.Add(simpleBlogArchiveRoute);



            //Routes from sample 2

            Route blogArchiveRoute = new Route(
                "archiveParam/{database}/{year}/{month}/{day}",
                new EventsRouteHandler()
                );

            blogArchiveRoute.Defaults = new RouteValueDictionary(
                                new
                                {
                                    year = 2008,
                                    month = 10,
                                    day = 5,
                                    controller = "Home",
                                    action = "IndexParam"
                                });

            blogArchiveRoute.Constraints = new RouteValueDictionary(
                    new
                    {
                        database = "sport|technology",
                        year = @"\d{2}|\d{4}",
                        month = @"\d{1,2}",
                        day = @"\d{1,2}"
                    });

            routes.Add(blogArchiveRoute);

            Route blogSportArchiveRoute = new Route(
                "archiveDT/sport/{year}/{month}/{day}",
                new EventsRouteHandler()
                );

            blogSportArchiveRoute.Defaults = new RouteValueDictionary(
                                new
                                {
                                    controller = "Home",
                                    action = "IndexDT"
                                });

            blogSportArchiveRoute.Constraints = new RouteValueDictionary(
                                new
                                {
                                    year = @"\d{2}|\d{4}",
                                    month = @"\d{1,2}",
                                    day = @"\d{1,2}"
                                });

            blogSportArchiveRoute.DataTokens = new RouteValueDictionary(
                                new
                                {
                                    database = "sportConnString"
                                });

            routes.Add(blogSportArchiveRoute);

            Route blogTechnologyArchiveRoute = new Route(
                "archiveDT/technology/{year}/{month}/{day}",
                new EventsRouteHandler()
                );

            blogTechnologyArchiveRoute.Defaults = new RouteValueDictionary(
                                new
                                {
                                    controller = "Home",
                                    action = "IndexDT"
                                });

            blogTechnologyArchiveRoute.Constraints = new RouteValueDictionary(
                                new
                                {
                                    year = @"\d{2}|\d{4}",
                                    month = @"\d{1,2}",
                                    day = @"\d{1,2}"
                                });

            blogTechnologyArchiveRoute.DataTokens = new RouteValueDictionary(
                                new
                                {
                                    database = "techConnString"
                                });

            routes.Add(blogTechnologyArchiveRoute);



            routes.MapRoute(
                "Default",                                              // Route name
                "{controller}/{action}/{id}",                           // URL with parameters
                new { controller = "Home", action = "Index", id = "" }  // Parameter defaults
            );

        }

        protected void Application_Start()
        {
            RouteTable.Routes.RouteExistingFiles = true;
            RegisterRoutes(RouteTable.Routes);
            //RouteDebug.RouteDebugger.RewriteRoutesForTesting(RouteTable.Routes);
        }
    }

    public class EventsRouteHandler : IRouteHandler
    {
        public IHttpHandler GetHttpHandler(RequestContext requestContext)
        {
            foreach (KeyValuePair<string, object> token in requestContext.RouteData.Values)
            {
                requestContext.HttpContext.Items.Add(token.Key, token.Value);
            }
            foreach (KeyValuePair<string, object> token in requestContext.RouteData.DataTokens)
            {
                requestContext.HttpContext.Items.Add(token.Key, token.Value);
            }
            IHttpHandler result = BuildManager
                .CreateInstanceFromVirtualPath("~/Events.aspx", typeof(Events)) as IHttpHandler;
            return result;
        }
    }

    public class DateIsValidConstraint : IRouteConstraint
    {
        public bool Match(HttpContextBase httpContext, Route route, string parameterName, RouteValueDictionary values, RouteDirection routeDirection)
        {
            object dayObj;
            if (!values.TryGetValue(parameterName, out dayObj))
            {
                return false;
            }
            int day = 0;
            if (Int32.TryParse(dayObj.ToString(), out day))
            {
                try
                {
                    DateTime date = new DateTime(
                        Convert.ToInt32(values["year"]),
                        Convert.ToInt32(values["month"]),
                        day
                        );
                    return true;
                }
                catch
                {
                    return false;
                }
            }
            return false;
        }
    }


}