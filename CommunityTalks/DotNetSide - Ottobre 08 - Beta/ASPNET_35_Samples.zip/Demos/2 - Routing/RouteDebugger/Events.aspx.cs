﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace RouteDebugger
{
    public partial class Events : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            List<Token> list = new List<Token>();
            foreach (DictionaryEntry entry in this.Context.Items)
            {
                if (entry.Key.ToString().ToLower().Equals(entry.Key.ToString()))
                list.Add(new Token()
                             {
                                 Name = entry.Key.ToString(),
                                 Value = entry.Value.ToString()
                             });
            }
            tokens.DataSource = list;
            tokens.DataBind();
        }
    }

    public class Token
    {
        public string Name { get; set; }
        public string Value { get; set; }
    }
}
