﻿using System.ComponentModel.DataAnnotations;

namespace DDDemo
{
    [ScaffoldTable(true)]
    public partial class subtext_Content
    {
    }
}
